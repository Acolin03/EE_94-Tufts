import scipy.io
import numpy as np
import sys

def audit_rram_dimensions(file_path):
    print(f"--- Dimensional Audit: {file_path} ---")
    data = scipy.io.loadmat(file_path)
    
    times = []
    energies = []
    
    # We loop through the keys we saw in your log (time_0, time_1, etc.)
    # There are roughly 300-650 sequences depending on the file
    for i in range(1000): # Safety range
        t_key, v_key, i_key = f'time_{i}', f'v_{i}', f'current_{i}'
        
        if t_key in data:
            t = data[t_key].flatten()
            v = data[v_key].flatten()
            c = data[i_key].flatten()
            
            # 1. Capture Total Switching Time (Dimension: Seconds)
            times.append(t[-1] - t[0])
            
            # 2. Estimate Energy (Dimension: Joules)
            # Energy = sum(|V * I| * dt)
            dt = np.diff(t)
            v_mid = (v[:-1] + v[1:]) / 2
            i_mid = (c[:-1] + c[1:]) / 2
            energy = np.sum(np.abs(v_mid * i_mid * dt))
            energies.append(energy)

    if not times:
        print("Error: No numbered time_N keys found.")
        return

    print(f"Total Sequences Found: {len(times)}")
    print(f"TIME Range:   {min(times):.2e} to {max(times):.2e} seconds")
    print(f"ENERGY Range: {min(energies):.2e} to {max(energies):.2e} Joules")

if __name__ == "__main__":
    if len(sys.argv) > 1:
        audit_rram_dimensions(sys.argv[1])