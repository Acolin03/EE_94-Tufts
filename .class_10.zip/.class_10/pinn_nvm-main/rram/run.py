import torch
import pandas as pd

# Update this line to allow loading the DataFrame
data = torch.load('ctgan_recommendation_results/rram_ctgan_dataset.pt', weights_only=False)

print("--- Training Data Distribution ---")
# Convert to nanoseconds and picojoules for Dimensional Awareness
print(f"Fastest Switching in Data: {data['latency'].min() * 1e9:.2f} ns")
print(f"Average Switching in Data: {data['latency'].mean() * 1e9:.2f} ns")
print(f"Lowest Energy in Data: {data['energy'].min() * 1e12:.2f} pJ")
print(f"Total Samples: {len(data)}")