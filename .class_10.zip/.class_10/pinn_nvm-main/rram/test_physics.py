import torch
from src.loss import simulate_rram

# 1. Create 1.5ns Pulses (The 'Action' Zone)
v = torch.tensor([5.0] * 10)  # Strong 5V pulse
dt = torch.tensor([1.5e-9] * 10) # 1.5ns steps
current = torch.tensor([1e-4] * 10) # 100uA baseline

# 2. Physical Constants (Standard HfO2 values)
# Note: These must be tensors for JIT
params = {
    'gamma0': torch.tensor(16.0), 'beta': torch.tensor(0.8), 'g1': torch.tensor(1e-9),
    'q': torch.tensor(1.602e-19), 'Eag': torch.tensor(1.2), 'kb': torch.tensor(1.38e-23),
    'a0': torch.tensor(0.25e-9), 'tox': torch.tensor(5e-9), 'Ear': torch.tensor(1.2),
    'Vel0': torch.tensor(10.0), # <--- WATCH THIS VALUE
    'gap_min': torch.tensor(0.1e-9), 'gap_max': torch.tensor(1.7e-9),
    'T0': torch.tensor(298.0), 'Cth': torch.tensor(3.18e-15), 'Tau_th': torch.tensor(0.23e-9)
}

# 3. Run Simulation
gap, temp = simulate_rram(dt, v, current, **params)

print(f"--- RRAM Physics Report ---")
print(f"Voltage applied: {v[0].item()}V for {dt.sum().item()*1e9:.1f} ns")
print(f"Initial Gap: {gap[0].item()*1e9:.4f} nm")
print(f"Final Gap:   {gap[-1].item()*1e9:.4f} nm")
print(f"Max Temp:    {temp.max().item():.2f} K")

if gap[0] == gap[-1]:
    print("\nRESULT: STATUS QUO. The ions are STILL FROZEN.")
    print("FIX: We must increase Vel0 or the Time Scale.")
else:
    print("\nRESULT: MOVEMENT DETECTED! The physics are alive.")