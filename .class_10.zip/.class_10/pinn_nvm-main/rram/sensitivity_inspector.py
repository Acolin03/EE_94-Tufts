import os
import sys
import torch
import pandas as pd
import numpy as np
import json
from tqdm import tqdm

# Adjust sys path for local imports
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from src.ctgan.ctgan_model import RRAMCTGANRecommender
from src.ctgan.ctgan_eval import RRAMEvaluator

def run_sensitivity_analysis(output_dir='ctgan_recommendation_results', 
                           num_samples=10000, 
                           model_path='checkpoints/pinn_sparse.pth',
                           data_path='data/rram_stanford.mat',
                           ctgan_model_path='ctgan_recommendation_results/ctgan_model.pkl',
                           dataset_path='ctgan_recommendation_results/rram_ctgan_dataset.pt'):
    
    print("--- Starting PI-GAN Sensitivity Inspection (Path 1) ---")
    
    # 1. Initialize
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    try:
        evaluator = RRAMEvaluator(model_path=model_path, data_path=data_path, output_dir=output_dir, device=device)
        recommender = RRAMCTGANRecommender(ctgan_model_path, evaluator, dataset_path=dataset_path, min_pulse_width=1e-9)
    except Exception as e:
        print(f"Error initializing models: {e}")
        return

    # 2. Sample or Load Cloud
    # We prioritize generating a fresh cloud if one doesn't exist or if we want to be sure
    # But since we want to analyze the 'behavior', generating new points is valid.
    print("Generating and Verifying candidates for Inspection...")
    try:
        df = recommender.sample_candidates(num_samples=num_samples)
        cloud_file = os.path.join(output_dir, 'sensitivity_cloud.csv')
        df.to_csv(cloud_file, index=False)
        print(f"Verified cloud saved to {cloud_file}")
    except Exception as e:
        print(f"Error during sampling: {e}")
        return

    # 3. Sensitivity Analysis
    print("Discovery: Design Rules & Sensitivity Mapping ---")
    
    materials = df['material'].unique()
    results = {}
    
    for mat in materials:
        mat_df = df[df['material'] == mat].copy()
        
        if len(mat_df) < 10:
            print(f"Skipping {mat}: Not enough points ({len(mat_df)})")
            continue

        # A. Define "Winners" (Best 10% closest to origin 0,0 - normalized)
        # We use a simple distance metric to finding the Pareto-like points
        # Normalize just for ranking
        e_norm = (mat_df['energy'] - mat_df['energy'].min()) / (mat_df['energy'].max() - mat_df['energy'].min())
        l_norm = (mat_df['latency'] - mat_df['latency'].min()) / (mat_df['latency'].max() - mat_df['latency'].min())
        mat_df['score'] = e_norm + l_norm
        
        winners = mat_df.nsmallest(int(len(mat_df) * 0.1), 'score')
        
        # B. Define "Ghosts" (Worst 10% - High Energy/Latency)
        ghosts = mat_df.nlargest(int(len(mat_df) * 0.1), 'score')
        
        # C. Calculate Magic Numbers (Voltages)
        vset_stats = {'mean': winners['Vset'].mean(), 'std': winners['Vset'].std()}
        vreset_stats = {'mean': winners['Vreset'].mean(), 'std': winners['Vreset'].std()}
        
        ghost_vset = {'mean': ghosts['Vset'].mean(), 'std': ghosts['Vset'].std()}
        
        print(f"Material: {mat}")
        print(f"  [Design Rule] Optimal Vset: {vset_stats['mean']:.3f}V ± {vset_stats['std']:.3f}V")
        print(f"  [Design Rule] Optimal Vreset: {vreset_stats['mean']:.3f}V ± {vreset_stats['std']:.3f}V")
        print(f"  --------------------------------------------------")
        print(f"  [The Trap] Ghost/High-Loss Vset avg: {ghost_vset['mean']:.3f}V")
        print(f"  [Impact] Winners: {winners['energy'].mean()*1e12:.1f}pJ | Ghosts: {ghosts['energy'].mean()*1e12:.1f}pJ")
        
        results[mat] = {
            'optimal_vset': (float(vset_stats['mean']), float(vset_stats['std'])),
            'optimal_vreset': (float(vreset_stats['mean']), float(vreset_stats['std'])),
            'ghost_vset_mean': float(ghost_vset['mean'])
        }

    # 4. Save Analysis Report
    report_file = os.path.join(output_dir, 'sensitivity_analysis_report.json')
    with open(report_file, 'w') as f:
        json.dump(results, f, indent=4)
    print(f"Sensitivity report saved to {report_file}")

if __name__ == "__main__":
    run_sensitivity_analysis()
